//
//  MessagingSDK.h
//  MessagingSDK
//
//  Created by Roysbert Salinas on 4/29/20.
//  Copyright © 2020 Messangi. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MessagingSDK.
FOUNDATION_EXPORT double MessagingSDKVersionNumber;

//! Project version string for MessagingSDK.
FOUNDATION_EXPORT const unsigned char MessagingSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MessagingSDK/PublicHeader.h>


