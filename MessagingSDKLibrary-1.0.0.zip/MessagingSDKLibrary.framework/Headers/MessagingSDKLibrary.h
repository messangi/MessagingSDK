//
//  MessagingSDKLibrary.h
//  MessagingSDKLibrary
//
//  Created by Betzabeth Gonzalez on 8/15/20.
//  Copyright © 2020 Messangi. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MessagingSDKLibrary.
FOUNDATION_EXPORT double MessagingSDKLibraryVersionNumber;

//! Project version string for MessagingSDKLibrary.
FOUNDATION_EXPORT const unsigned char MessagingSDKLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MessagingSDKLibrary/PublicHeader.h>


